import React, { useState, useEffect } from 'react';
import { Search, Plus, Users, LogOut, User } from 'lucide-react';
import { calculateAge } from './utils/dateUtils';
import { loadFromStorage, saveToStorage } from './utils/storageUtils';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './components/Login';
import Header from './components/Header';
import ClientForm from './components/ClientForm';
import ClientTable from './components/ClientTable';
import ClientDetail from './components/ClientDetail';
import Statistics from './components/Statistics';
import StaffManagement from './components/StaffManagement';

function AppContent() {
  const { currentUser, logout } = useAuth();
  const [clients, setClients] = useState(() => loadFromStorage());
  const [selectedClient, setSelectedClient] = useState(null);
  const [viewMode, setViewMode] = useState('list'); // 'list', 'detail', 'staff'
  const [isClientFormOpen, setIsClientFormOpen] = useState(false);
  const [editingClientId, setEditingClientId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const [clientForm, setClientForm] = useState({
    clientId: '',
    name: '',
    kana: '',
    birthDate: '',
    gender: '男性',
    phone: '',
    area: '',
    bloodType: '',
    referrer: '',
    assignedStaff: '',
    sessionPrice: ''
  });

  // データが変更されたらLocalStorageに保存
  useEffect(() => {
    saveToStorage(clients);
  }, [clients]);

  const resetClientForm = () => {
    setClientForm({
      clientId: '',
      name: '',
      kana: '',
      birthDate: '',
      gender: '男性',
      phone: '',
      area: '',
      bloodType: '',
      referrer: '',
      assignedStaff: '',
      sessionPrice: ''
    });
    setIsClientFormOpen(false);
    setEditingClientId(null);
  };

  const handleClientSubmit = (e) => {
    e.preventDefault();
    const age = calculateAge(clientForm.birthDate);

    if (editingClientId) {
      setClients(clients.map(c =>
        c.id === editingClientId
          ? { ...clientForm, id: editingClientId, age, sessions: c.sessions }
          : c
      ));
    } else {
      setClients([...clients, {
        ...clientForm,
        id: Date.now(),
        age,
        sessions: []
      }]);
    }
    resetClientForm();
  };

  const handleEditClient = (client) => {
    setClientForm(client);
    setEditingClientId(client.id);
    setIsClientFormOpen(true);
    setViewMode('list');
  };

  const handleDeleteClient = (id) => {
    setClients(clients.filter(c => c.id !== id));
    if (selectedClient && selectedClient.id === id) {
      setSelectedClient(null);
      setViewMode('list');
    }
  };

  const handleAddSession = (clientId, newSession) => {
    setClients(clients.map(c =>
      c.id === clientId
        ? { ...c, sessions: [...c.sessions, newSession] }
        : c
    ));
    
    if (selectedClient && selectedClient.id === clientId) {
      setSelectedClient({
        ...selectedClient,
        sessions: [...selectedClient.sessions, newSession]
      });
    }
  };

  const handleDeleteSession = (clientId, sessionId) => {
    setClients(clients.map(c =>
      c.id === clientId
        ? { ...c, sessions: c.sessions.filter(s => s.id !== sessionId) }
        : c
    ));
    
    if (selectedClient && selectedClient.id === clientId) {
      setSelectedClient({
        ...selectedClient,
        sessions: selectedClient.sessions.filter(s => s.id !== sessionId)
      });
    }
  };

  const handleClientSelect = (client) => {
    setSelectedClient(client);
    setViewMode('detail');
  };

  const filteredClients = clients.filter(c =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.kana.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.clientId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleLogout = async () => {
    await logout();
    setViewMode('list');
  };

  // 担当者管理ビュー
  if (viewMode === 'staff') {
    return <StaffManagement onBack={() => setViewMode('list')} />;
  }

  // クライアント詳細ビュー
  if (viewMode === 'detail' && selectedClient) {
    return (
      <ClientDetail
        client={selectedClient}
        onBack={() => setViewMode('list')}
        onEdit={handleEditClient}
        onDelete={handleDeleteClient}
        onAddSession={handleAddSession}
        onDeleteSession={handleDeleteSession}
      />
    );
  }

  // クライアント一覧ビュー
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50 p-3 md:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-4 md:p-6">
          {/* ユーザー情報バー */}
          <div className="bg-gradient-to-r from-blue-50 to-cyan-50 p-3 rounded-lg mb-4 flex justify-between items-center border border-cyan-200">
            <div className="flex items-center gap-2">
              <User className="text-cyan-600" size={18} />
              <span className="text-sm text-gray-700">
                ログイン中: <strong>{currentUser.email}</strong>
              </span>
              <span className="text-xs bg-cyan-500 text-white px-2 py-1 rounded">
                {currentUser.role === 'admin' ? '管理者' : currentUser.role === 'editor' ? '編集者' : '担当者'}
              </span>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-800 transition"
            >
              <LogOut size={16} />
              ログアウト
            </button>
          </div>

          {/* ヘッダー */}
          <Header clients={clients} setClients={setClients} />

          {/* 検索バー、新規登録ボタン、担当者管理ボタン */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="クライアント名、カナ、クライアントIDで検索..."
                className="w-full pl-10 pr-4 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setViewMode('staff')}
                className="flex items-center gap-2 bg-blue-500 text-white px-4 md:px-6 py-2 rounded-lg hover:bg-blue-600 transition shadow-md font-semibold"
              >
                <Users size={20} />
                <span className="hidden sm:inline">担当者管理</span>
              </button>
              <button
                onClick={() => {
                  setIsClientFormOpen(true);
                  setEditingClientId(null);
                  resetClientForm();
                }}
                className="flex items-center gap-2 bg-cyan-400 text-white px-4 md:px-6 py-2 rounded-lg hover:bg-cyan-500 transition shadow-md font-semibold"
              >
                <Plus size={20} />
                <span className="hidden sm:inline">新規クライアント登録</span>
                <span className="sm:hidden">新規登録</span>
              </button>
            </div>
          </div>

          {/* クライアントフォーム */}
          {isClientFormOpen && (
            <ClientForm
              clientForm={clientForm}
              setClientForm={setClientForm}
              onSubmit={handleClientSubmit}
              onCancel={resetClientForm}
              editingClientId={editingClientId}
            />
          )}

          {/* クライアント一覧テーブル */}
          <ClientTable
            clients={filteredClients}
            onClientSelect={handleClientSelect}
          />

          {/* 統計情報 */}
          <Statistics clients={clients} />
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppRouter />
    </AuthProvider>
  );
}

function AppRouter() {
  const { currentUser, login } = useAuth();

  if (!currentUser) {
    return <Login onLogin={login} />;
  }

  return <AppContent />;
}

export default App;
