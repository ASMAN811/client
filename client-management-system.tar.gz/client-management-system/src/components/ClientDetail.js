import React, { useState } from 'react';
import { ArrowLeft, Edit, Trash2, Plus } from 'lucide-react';
import { calculateSpiritualNumber, getSpiritualInfo } from '../utils/spiritualNumber';
import SessionForm from './SessionForm';
import SessionList from './SessionList';

const ClientDetail = ({ 
  client, 
  onBack, 
  onEdit, 
  onDelete,
  onAddSession,
  onDeleteSession
}) => {
  const [isSessionFormOpen, setIsSessionFormOpen] = useState(false);
  const [sessionForm, setSessionForm] = useState({
    date: new Date().toISOString().split('T')[0],
    staff: '',
    duration: '',
    content: '',
    topic: '',
    rootEmotion: '',
    notes: '',
    jurisdiction: '',
    nextSession: '',
    remarks: ''
  });

  const handleSessionSubmit = (e) => {
    e.preventDefault();
    const newSession = {
      ...sessionForm,
      id: Date.now()
    };
    onAddSession(client.id, newSession);
    resetSessionForm();
  };

  const resetSessionForm = () => {
    setSessionForm({
      date: new Date().toISOString().split('T')[0],
      staff: '',
      duration: '',
      content: '',
      topic: '',
      rootEmotion: '',
      notes: '',
      jurisdiction: '',
      nextSession: '',
      remarks: ''
    });
    setIsSessionFormOpen(false);
  };

  const spiritualNum = calculateSpiritualNumber(client.birthDate);
  const spiritualInfo = getSpiritualInfo(spiritualNum);

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50 p-3 md:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-4 md:p-6">
          {/* 戻るボタン */}
          <button 
            onClick={onBack}
            className="mb-4 text-cyan-700 hover:text-cyan-900 font-medium flex items-center gap-2"
          >
            <ArrowLeft size={20} />
            クライアント一覧に戻る
          </button>

          {/* クライアント情報ヘッダー */}
          <div className="border-b-4 border-cyan-400 pb-4 mb-6">
            <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-cyan-800">{client.name}</h1>
                <p className="text-sm text-gray-600 mt-1">クライアントID: {client.clientId}</p>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={() => onEdit(client)}
                  className="flex items-center gap-2 bg-cyan-400 text-white px-4 py-2 rounded-lg hover:bg-cyan-500 transition shadow-md font-semibold"
                >
                  <Edit size={18} />
                  クライアント情報編集
                </button>
                <button 
                  onClick={() => {
                    if (window.confirm(`${client.name}さんのデータを削除しますか？この操作は取り消せません。`)) {
                      onDelete(client.id);
                    }
                  }}
                  className="flex items-center gap-2 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition shadow-md"
                >
                  <Trash2 size={18} />
                  削除
                </button>
              </div>
            </div>
          </div>

          {/* クライアント詳細情報 */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <p className="text-sm text-gray-600 mb-1">生年月日</p>
              <p className="text-lg font-semibold text-gray-800">
                {client.birthDate} ({client.age}歳)
              </p>
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <p className="text-sm text-gray-600 mb-1">スピリチュアルNo.</p>
              {spiritualInfo ? (
                <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full ${spiritualInfo.bgColor} ${spiritualInfo.textColor} border ${spiritualInfo.borderColor}`}>
                  <span className="text-lg font-bold">{spiritualNum}</span>
                  <span className="text-sm font-medium">{spiritualInfo.name}（{spiritualInfo.color}）</span>
                </div>
              ) : (
                <p className="text-lg font-semibold text-gray-800">—</p>
              )}
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <p className="text-sm text-gray-600 mb-1">性別</p>
              <p className="text-lg font-semibold text-gray-800">{client.gender}</p>
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <p className="text-sm text-gray-600 mb-1">血液型</p>
              <p className="text-lg font-semibold text-gray-800">{client.bloodType}</p>
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <p className="text-sm text-gray-600 mb-1">電話番号</p>
              <p className="text-lg font-semibold text-gray-800">{client.phone}</p>
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <p className="text-sm text-gray-600 mb-1">地域</p>
              <p className="text-lg font-semibold text-gray-800">{client.area}</p>
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <p className="text-sm text-gray-600 mb-1">セッション金額</p>
              <p className="text-lg font-semibold text-gray-800">
                ¥{client.sessionPrice ? Number(client.sessionPrice).toLocaleString() : '—'}
              </p>
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <p className="text-sm text-gray-600 mb-1">紹介者</p>
              <p className="text-lg font-semibold text-gray-800">{client.referrer || '—'}</p>
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <p className="text-sm text-gray-600 mb-1">担当者</p>
              <p className="text-lg font-semibold text-cyan-700">{client.assignedStaff}</p>
            </div>
          </div>

          {/* セッション記録セクション */}
          <div className="border-t-2 border-cyan-200 pt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-cyan-800">セッション記録</h2>
              <button 
                onClick={() => setIsSessionFormOpen(true)}
                className="flex items-center gap-2 bg-cyan-500 text-white px-4 py-2 rounded-lg hover:bg-cyan-600 transition shadow-md"
              >
                <Plus size={18} />
                新規セッション追加
              </button>
            </div>

            {/* セッションフォーム */}
            {isSessionFormOpen && (
              <SessionForm
                sessionForm={sessionForm}
                setSessionForm={setSessionForm}
                onSubmit={handleSessionSubmit}
                onCancel={resetSessionForm}
              />
            )}

            {/* セッション一覧 */}
            <SessionList
              sessions={client.sessions}
              onDelete={(sessionId) => onDeleteSession(client.id, sessionId)}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClientDetail;
