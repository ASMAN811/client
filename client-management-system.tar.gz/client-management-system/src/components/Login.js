import React, { useState } from 'react';
import { LogIn, Mail, Lock } from 'lucide-react';

const Login = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('staff');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    if (!email || !email.includes('@')) {
      setError('有効なメールアドレスを入力してください');
      return;
    }

    onLogin(email, role);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl p-8 max-w-md w-full">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-cyan-100 rounded-full mb-4">
            <LogIn className="text-cyan-600" size={32} />
          </div>
          <h1 className="text-3xl font-bold text-cyan-800 mb-2">ログイン</h1>
          <p className="text-gray-600">クライアント管理システム</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Mail className="inline mr-2" size={16} />
              メールアドレス
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="example@gmail.com"
              className="w-full px-4 py-3 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-400"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Lock className="inline mr-2" size={16} />
              権限
            </label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="w-full px-4 py-3 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-400"
            >
              <option value="staff">担当者</option>
              <option value="editor">編集者</option>
              <option value="admin">管理者</option>
            </select>
            <p className="text-xs text-gray-500 mt-2">
              ※デモ版では権限を選択できます
            </p>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-cyan-500 text-white py-3 rounded-lg hover:bg-cyan-600 transition font-semibold shadow-md flex items-center justify-center gap-2"
          >
            <LogIn size={20} />
            ログイン
          </button>
        </form>

        <div className="mt-8 p-4 bg-cyan-50 rounded-lg border border-cyan-200">
          <h3 className="font-semibold text-cyan-800 mb-2 text-sm">権限について</h3>
          <ul className="text-xs text-gray-700 space-y-1">
            <li>• <strong>管理者</strong>: 全ての機能にアクセス可能</li>
            <li>• <strong>編集者</strong>: クライアント・担当者情報の編集が可能</li>
            <li>• <strong>担当者</strong>: 自分のプロフィールのみ編集可能</li>
          </ul>
        </div>

        <div className="mt-6 text-center text-xs text-gray-500">
          <p>本番環境ではGmail認証（Firebase Auth）を使用します</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
