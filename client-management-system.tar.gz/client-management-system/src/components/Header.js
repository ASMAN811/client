import React from 'react';
import { exportClientsToCSV, exportSessionsToCSV, exportBackupToJSON, importFromJSON } from '../utils/exportUtils';

const Header = ({ clients, setClients }) => {
  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (file) {
        importFromJSON(
          file,
          (importedData) => {
            if (window.confirm('データをインポートしますか？現在のデータは上書きされます。')) {
              setClients(importedData);
              alert('データをインポートしました！');
            }
          },
          () => {
            alert('ファイルの読み込みに失敗しました。');
          }
        );
      }
    };
    input.click();
  };

  return (
    <div className="border-b-4 border-cyan-400 pb-3 md:pb-4 mb-4 md:mb-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-3">
        <div>
          <h1 className="text-xl md:text-3xl font-bold text-cyan-800">クライアント管理システム</h1>
          <p className="text-xs md:text-sm text-cyan-600 mt-1">Client Management System</p>
        </div>
        <div className="flex flex-wrap gap-2 items-center">
          <button
            onClick={() => exportClientsToCSV(clients)}
            className="text-sm bg-cyan-500 text-white px-4 py-2 rounded-lg hover:bg-cyan-600 transition font-medium shadow-sm"
          >
            クライアントエクスポート
          </button>
          <button
            onClick={() => exportSessionsToCSV(clients)}
            className="text-sm bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition font-medium shadow-sm"
          >
            セッションエクスポート
          </button>
          <button
            onClick={() => exportBackupToJSON(clients)}
            className="text-xs bg-gray-400 text-white px-3 py-2 rounded hover:bg-gray-500 transition"
          >
            バックアップ
          </button>
          <button
            onClick={handleImport}
            className="text-xs bg-gray-400 text-white px-3 py-2 rounded hover:bg-gray-500 transition"
          >
            復元
          </button>
        </div>
      </div>
    </div>
  );
};

export default Header;
