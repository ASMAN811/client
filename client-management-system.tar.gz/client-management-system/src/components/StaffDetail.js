import React from 'react';
import { ArrowLeft, Edit, Trash2, Briefcase, Award, Users, MapPin, Calendar, Phone, MessageCircle, Clock, Target, FileText, Mail } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const StaffDetail = ({ staff, onBack, onEdit, onDelete }) => {
  const { hasPermission, isOwnProfile } = useAuth();
  
  const canEdit = hasPermission('editor') || isOwnProfile(staff.email);
  const canDelete = hasPermission('admin');

  const formatDate = (dateString) => {
    if (!dateString) return '未設定';
    const date = new Date(dateString);
    return date.toLocaleString('ja-JP', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50 p-3 md:p-6">
      <div className="max-w-5xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-4 md:p-6">
          {/* 戻るボタン */}
          <button 
            onClick={onBack}
            className="mb-4 text-cyan-700 hover:text-cyan-900 font-medium flex items-center gap-2"
          >
            <ArrowLeft size={20} />
            担当者一覧に戻る
          </button>

          {/* 担当者情報ヘッダー */}
          <div className="border-b-4 border-cyan-400 pb-4 mb-6">
            <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-cyan-800">{staff.name}</h1>
                <p className="text-sm text-gray-600 mt-1">ふりがな: {staff.kana}</p>
                <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                  <Mail size={14} />
                  {staff.email}
                </p>
              </div>
              <div className="flex gap-3">
                {canEdit && (
                  <button 
                    onClick={() => onEdit(staff)}
                    className="flex items-center gap-2 bg-cyan-400 text-white px-4 py-2 rounded-lg hover:bg-cyan-500 transition shadow-md font-semibold"
                  >
                    <Edit size={18} />
                    編集
                  </button>
                )}
                {canDelete && (
                  <button 
                    onClick={() => {
                      if (window.confirm(`${staff.name}さんの情報を削除しますか？この操作は取り消せません。`)) {
                        onDelete(staff.id);
                      }
                    }}
                    className="flex items-center gap-2 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition shadow-md"
                  >
                    <Trash2 size={18} />
                    削除
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* 編集履歴 */}
          {(staff.lastEditBy || staff.createdBy) && (
            <div className="bg-blue-50 p-3 rounded-lg mb-6 border border-blue-200">
              <div className="text-xs text-gray-700 space-y-1">
                {staff.createdBy && (
                  <p>
                    <span className="font-semibold">作成者:</span> {staff.createdBy}
                    {staff.createdAt && ` (${formatDate(staff.createdAt)})`}
                  </p>
                )}
                {staff.lastEditBy && (
                  <p>
                    <span className="font-semibold">最終編集:</span> {staff.lastEditBy}
                    {staff.lastEditAt && ` (${formatDate(staff.lastEditAt)})`}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* 基本情報カード */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="text-cyan-600" size={20} />
                <p className="text-sm font-semibold text-gray-700">生年月日</p>
              </div>
              <p className="text-lg font-semibold text-gray-800 ml-7">
                {staff.birthDate ? `${staff.birthDate} (${staff.age}歳)` : '未設定'}
              </p>
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <div className="flex items-center gap-2 mb-2">
                <MapPin className="text-cyan-600" size={20} />
                <p className="text-sm font-semibold text-gray-700">居住地</p>
              </div>
              <p className="text-lg font-semibold text-gray-800 ml-7">
                {staff.location || '未設定'}
              </p>
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <div className="flex items-center gap-2 mb-2">
                <Phone className="text-cyan-600" size={20} />
                <p className="text-sm font-semibold text-gray-700">電話番号</p>
              </div>
              <p className="text-lg font-semibold text-gray-800 ml-7">
                {staff.phone || '未設定'}
              </p>
            </div>

            <div className="bg-cyan-50 p-4 rounded-lg border border-cyan-200">
              <div className="flex items-center gap-2 mb-2">
                <MessageCircle className="text-cyan-600" size={20} />
                <p className="text-sm font-semibold text-gray-700">LINE ID</p>
              </div>
              <p className="text-lg font-semibold text-gray-800 ml-7">
                {staff.lineId || '未設定'}
              </p>
            </div>
          </div>

          {/* 家族構成 */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-lg border border-purple-200">
              <div className="flex items-center gap-2 mb-2">
                <Users className="text-purple-600" size={20} />
                <p className="text-sm font-semibold text-gray-700">姉妹兄弟構成</p>
              </div>
              <p className="text-gray-800 ml-7">
                {staff.siblingsStructure || '未設定'}
              </p>
            </div>

            <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-lg border border-purple-200">
              <div className="flex items-center gap-2 mb-2">
                <Users className="text-purple-600" size={20} />
                <p className="text-sm font-semibold text-gray-700">家族構成</p>
              </div>
              <p className="text-gray-800 ml-7">
                {staff.familyStructure || '未設定'}
              </p>
            </div>
          </div>

          {/* DNA歴 */}
          <div className="bg-gradient-to-r from-cyan-50 to-blue-50 p-5 rounded-lg border-2 border-cyan-200 mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Award className="text-cyan-700" size={24} />
              <h2 className="text-xl font-bold text-cyan-800">DNA歴</h2>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                {staff.dnaHistory || 'DNA歴は登録されていません。'}
              </p>
            </div>
          </div>

          {/* 職業経歴 */}
          <div className="bg-gradient-to-r from-cyan-50 to-blue-50 p-5 rounded-lg border-2 border-cyan-200 mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Briefcase className="text-cyan-700" size={24} />
              <h2 className="text-xl font-bold text-cyan-800">職業経歴</h2>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                {staff.careerHistory || '職業経歴は登録されていません。'}
              </p>
            </div>
          </div>

          {/* 公的資格 */}
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-5 rounded-lg border-2 border-green-200 mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Award className="text-green-700" size={24} />
              <h2 className="text-xl font-bold text-green-800">公的な資格</h2>
            </div>
            <div className="bg-white p-4 rounded-lg">
              {staff.certifications ? (
                <div className="space-y-2">
                  {staff.certifications.split(/[\n]/).filter(cert => cert.trim()).map((cert, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <p className="text-gray-700">{cert.trim()}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">公的な資格は登録されていません。</p>
              )}
            </div>
          </div>

          {/* 稼働可能時間 */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-5 rounded-lg border-2 border-blue-200 mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Clock className="text-blue-700" size={24} />
              <h2 className="text-xl font-bold text-blue-800">稼働可能時間</h2>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                {staff.availableHours || '稼働可能時間は登録されていません。'}
              </p>
            </div>
          </div>

          {/* 使命 */}
          <div className="bg-gradient-to-r from-yellow-50 to-amber-50 p-5 rounded-lg border-2 border-yellow-200 mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Target className="text-yellow-700" size={24} />
              <h2 className="text-xl font-bold text-yellow-800">自身の使命</h2>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                {staff.mission || '使命は登録されていません。'}
              </p>
            </div>
          </div>

          {/* その他 */}
          {staff.otherInfo && (
            <div className="bg-gradient-to-r from-gray-50 to-slate-50 p-5 rounded-lg border-2 border-gray-200">
              <div className="flex items-center gap-2 mb-3">
                <FileText className="text-gray-700" size={24} />
                <h2 className="text-xl font-bold text-gray-800">その他</h2>
              </div>
              <div className="bg-white p-4 rounded-lg">
                <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                  {staff.otherInfo}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StaffDetail;
