import React from 'react';
import { Eye, Edit, Trash2 } from 'lucide-react';

const StaffList = ({ staff, onStaffSelect, onEdit, onDelete }) => {
  return (
    <div className="overflow-x-auto shadow-md rounded-lg">
      <table className="w-full min-w-[640px]">
        <thead className="bg-cyan-400 text-white">
          <tr>
            <th className="px-2 md:px-4 py-2 md:py-3 text-left text-xs md:text-sm font-semibold">氏名</th>
            <th className="px-2 md:px-4 py-2 md:py-3 text-left text-xs md:text-sm font-semibold hidden md:table-cell">ふりがな</th>
            <th className="px-2 md:px-4 py-2 md:py-3 text-left text-xs md:text-sm font-semibold hidden lg:table-cell">居住地</th>
            <th className="px-2 md:px-4 py-2 md:py-3 text-left text-xs md:text-sm font-semibold hidden sm:table-cell">セラピスト歴</th>
            <th className="px-2 md:px-4 py-2 md:py-3 text-center text-xs md:text-sm font-semibold">操作</th>
          </tr>
        </thead>
        <tbody>
          {staff.map((person, index) => (
            <tr key={person.id} className={index % 2 === 0 ? 'bg-white' : 'bg-cyan-50'}>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm font-medium">
                <button 
                  onClick={() => onStaffSelect(person)}
                  className="text-cyan-600 hover:text-cyan-800 hover:underline font-semibold"
                >
                  {person.name}
                </button>
              </td>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm text-gray-600 hidden md:table-cell">
                {person.kana}
              </td>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm text-gray-700 hidden lg:table-cell">
                {person.location}
              </td>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm text-cyan-700 font-medium hidden sm:table-cell">
                {person.therapistYears}
              </td>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm">
                <div className="flex justify-center gap-2">
                  <button 
                    onClick={() => onStaffSelect(person)}
                    className="text-cyan-600 hover:text-cyan-800" 
                    title="詳細"
                  >
                    <Eye size={16} className="md:w-[18px] md:h-[18px]" />
                  </button>
                  <button 
                    onClick={() => onEdit(person)}
                    className="text-blue-600 hover:text-blue-800" 
                    title="編集"
                  >
                    <Edit size={16} className="md:w-[18px] md:h-[18px]" />
                  </button>
                  <button 
                    onClick={() => {
                      if (window.confirm(`${person.name}さんの情報を削除しますか？`)) {
                        onDelete(person.id);
                      }
                    }}
                    className="text-red-600 hover:text-red-800" 
                    title="削除"
                  >
                    <Trash2 size={16} className="md:w-[18px] md:h-[18px]" />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {staff.length === 0 && (
        <div className="text-center py-8 text-gray-500 bg-white">
          担当者情報がありません
        </div>
      )}
    </div>
  );
};

export default StaffList;
