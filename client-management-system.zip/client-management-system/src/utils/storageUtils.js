const STORAGE_KEY = 'clientManagementData';

// 初期データ
const getInitialData = () => [{
  id: 1,
  clientId: 'C2024001',
  name: '山田太郎',
  kana: 'ヤマダタロウ',
  birthDate: '1980-05-15',
  age: 44,
  gender: '男性',
  phone: '090-1234-5678',
  area: '東京都渋谷区',
  bloodType: 'A型',
  referrer: '田中様からのご紹介',
  assignedStaff: '佐藤担当者',
  sessionPrice: 10000,
  sessions: [{
    id: 1,
    date: '2024-11-01',
    staff: '佐藤担当者',
    duration: '60分',
    content: 'キャリアに関する相談、今後の方向性について',
    topic: '仕事とプライベートのバランス',
    rootEmotion: '不安、焦燥感',
    notes: '最近の業務過多により疲労が蓄積',
    jurisdiction: '東京オフィス',
    nextSession: '次回は具体的なアクションプランを策定予定',
    remarks: '定期的なフォローアップが必要'
  }]
}];

// LocalStorageからデータを読み込む
export const loadFromStorage = () => {
  const savedClients = localStorage.getItem(STORAGE_KEY);
  
  if (savedClients) {
    try {
      return JSON.parse(savedClients);
    } catch (e) {
      console.error('データの読み込みに失敗しました:', e);
      return getInitialData();
    }
  }
  
  return getInitialData();
};

// LocalStorageにデータを保存する
export const saveToStorage = (clients) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(clients));
  } catch (e) {
    console.error('データの保存に失敗しました:', e);
  }
};
