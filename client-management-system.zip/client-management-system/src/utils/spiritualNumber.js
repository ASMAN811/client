// スピリチュアルナンバー計算関数
export const calculateSpiritualNumber = (birthDate) => {
  if (!birthDate) return null;
  const [year, month, day] = birthDate.split('-').map(Number);
  let sum = month + day;
  
  // 11, 22, 33のゾロ目をチェック
  while (sum > 9 && sum !== 11 && sum !== 22 && sum !== 33) {
    sum = String(sum).split('').reduce((acc, digit) => acc + Number(digit), 0);
  }
  
  return sum;
};

// スピリチュアルナンバーの情報を取得
export const getSpiritualInfo = (number) => {
  const spiritualMap = {
    1: { name: '進化', color: 'white', bgColor: 'bg-gray-100', textColor: 'text-gray-800', borderColor: 'border-gray-300' },
    2: { name: '調和', color: 'black', bgColor: 'bg-gray-800', textColor: 'text-white', borderColor: 'border-gray-900' },
    3: { name: '勇気', color: 'blue', bgColor: 'bg-blue-500', textColor: 'text-white', borderColor: 'border-blue-600' },
    4: { name: '愛', color: 'green', bgColor: 'bg-green-500', textColor: 'text-white', borderColor: 'border-green-600' },
    5: { name: '吾', color: 'yellow', bgColor: 'bg-yellow-400', textColor: 'text-gray-800', borderColor: 'border-yellow-500' },
    6: { name: '創造', color: 'white', bgColor: 'bg-gray-100', textColor: 'text-gray-800', borderColor: 'border-gray-300' },
    7: { name: '信念', color: 'red', bgColor: 'bg-red-500', textColor: 'text-white', borderColor: 'border-red-600' },
    8: { name: '希望', color: 'white', bgColor: 'bg-gray-100', textColor: 'text-gray-800', borderColor: 'border-gray-300' },
    9: { name: '純正', color: 'purple', bgColor: 'bg-purple-500', textColor: 'text-white', borderColor: 'border-purple-600' },
    11: { name: '進化', color: 'white', bgColor: 'bg-gray-100', textColor: 'text-gray-800', borderColor: 'border-gray-300' },
    22: { name: '調和', color: 'black', bgColor: 'bg-gray-800', textColor: 'text-white', borderColor: 'border-gray-900' },
    33: { name: '勇気', color: 'blue', bgColor: 'bg-blue-500', textColor: 'text-white', borderColor: 'border-blue-600' }
  };
  
  return spiritualMap[number] || null;
};
