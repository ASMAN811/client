const STAFF_STORAGE_KEY = 'staffManagementData';

// 初期スタッフデータ
const getInitialStaffData = () => [{
  id: 1,
  email: 'sato@example.com',
  name: '佐藤担当者',
  kana: 'サトウタントウシャ',
  birthDate: '1985-03-20',
  age: 39,
  location: '東京都渋谷区',
  dnaHistory: 'DNA Basic修了 (2020年)\nDNA Advance修了 (2021年)\nDNA Theta修了 (2022年)',
  careerHistory: '■ 2005年〜2015年: 株式会社○○\n人事部門にて採用・教育研修を担当\n年間100名以上の面接を実施\n新入社員研修プログラムの企画・運営\n\n■ 2015年〜2020年: 株式会社△△\nキャリアコンサルタントとして活動\n個別キャリア相談 累計300件以上\n企業向けキャリア研修の実施\n\n■ 2020年〜現在: 独立開業\n心理カウンセラー・セラピストとして活動\n個人セッション累計500件以上\n企業向けメンタルヘルス研修の実施',
  certifications: '公認心理師（登録番号: 12345）\nキャリアコンサルタント（国家資格）\n産業カウンセラー\n認定心理士',
  siblingsStructure: '3人兄弟の長男（弟2人）',
  familyStructure: '既婚、配偶者と子供2人（長女10歳、次女7歳）',
  availableHours: '平日: 10:00-18:00\n土曜: 10:00-15:00\n日曜・祝日: 休み',
  phone: '090-1234-5678',
  lineId: 'sato_therapist',
  mission: 'クライアントが本来の自分らしさを取り戻し、人生の可能性を最大限に発揮できるようサポートすること。一人ひとりの内なる声に耳を傾け、真の変容と成長を促すことを使命としています。',
  otherInfo: '得意分野: キャリア相談、人間関係の悩み、自己実現\n趣味: 読書、ヨガ、瞑想\n好きな言葉: 「今この瞬間を生きる」',
  lastEditBy: null,
  lastEditAt: null,
  createdBy: 'system',
  createdAt: new Date().toISOString()
}];

// LocalStorageからスタッフデータを読み込む
export const loadStaffFromStorage = () => {
  const savedStaff = localStorage.getItem(STAFF_STORAGE_KEY);
  
  if (savedStaff) {
    try {
      return JSON.parse(savedStaff);
    } catch (e) {
      console.error('スタッフデータの読み込みに失敗しました:', e);
      return getInitialStaffData();
    }
  }
  
  return getInitialStaffData();
};

// LocalStorageにスタッフデータを保存する
export const saveStaffToStorage = (staff) => {
  try {
    localStorage.setItem(STAFF_STORAGE_KEY, JSON.stringify(staff));
  } catch (e) {
    console.error('スタッフデータの保存に失敗しました:', e);
  }
};

// スタッフデータに編集履歴を追加
export const updateStaffWithHistory = (staff, updatedData, editorEmail) => {
  return staff.map(s => {
    if (s.id === updatedData.id || s.email === updatedData.email) {
      return {
        ...updatedData,
        lastEditBy: editorEmail,
        lastEditAt: new Date().toISOString()
      };
    }
    return s;
  });
};

// 新規スタッフ作成時の初期データ
export const createNewStaff = (formData, creatorEmail) => {
  return {
    ...formData,
    id: Date.now(),
    createdBy: creatorEmail,
    createdAt: new Date().toISOString(),
    lastEditBy: null,
    lastEditAt: null
  };
};
