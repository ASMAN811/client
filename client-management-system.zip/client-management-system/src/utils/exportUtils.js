// CSVエクスポート関数（クライアント情報）
export const exportClientsToCSV = (clients) => {
  let csvContent = 'クライアントID,氏名,カナ,生年月日,年齢,性別,電話番号,地域,血液型,紹介者,担当者,セッション金額\n';
  
  clients.forEach(client => {
    const row = [
      client.clientId,
      client.name,
      client.kana,
      client.birthDate,
      client.age,
      client.gender,
      client.phone,
      client.area,
      client.bloodType,
      client.referrer || '',
      client.assignedStaff,
      client.sessionPrice || ''
    ].map(cell => `"${cell}"`).join(',');
    csvContent += row + '\n';
  });
  
  downloadFile(csvContent, `クライアント情報_${getTodayString()}.csv`, 'text/csv');
};

// CSVエクスポート関数（セッション記録）
export const exportSessionsToCSV = (clients) => {
  let csvContent = 'クライアントID,クライアント名,セッション日,担当者,所要時間,お題,内容,根本感情,特記事項,所管,次回への申し送り事項,備考\n';
  
  clients.forEach(client => {
    client.sessions.forEach(session => {
      const row = [
        client.clientId,
        client.name,
        session.date,
        session.staff,
        session.duration,
        session.topic,
        session.content,
        session.rootEmotion,
        session.notes || '',
        session.jurisdiction,
        session.nextSession || '',
        session.remarks || ''
      ].map(cell => `"${cell}"`).join(',');
      csvContent += row + '\n';
    });
  });
  
  downloadFile(csvContent, `セッション記録_${getTodayString()}.csv`, 'text/csv');
};

// JSONバックアップ関数
export const exportBackupToJSON = (clients) => {
  const dataStr = JSON.stringify(clients, null, 2);
  downloadFile(dataStr, `全データバックアップ_${getTodayString()}.json`, 'application/json');
};

// ファイルダウンロード共通関数
const downloadFile = (content, filename, mimeType) => {
  // BOMを追加してExcelで文字化けを防ぐ
  const bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
  const blob = new Blob([bom, content], { type: `${mimeType};charset=utf-8;` });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
};

// 今日の日付を文字列で取得
const getTodayString = () => {
  return new Date().toISOString().split('T')[0];
};

// JSONインポート処理
export const importFromJSON = (file, onSuccess, onError) => {
  const reader = new FileReader();
  
  reader.onload = (event) => {
    try {
      const importedData = JSON.parse(event.target.result);
      onSuccess(importedData);
    } catch (error) {
      onError(error);
    }
  };
  
  reader.readAsText(file);
};
