import React, { createContext, useContext, useState, useEffect } from 'react';

// 本番環境では Firebase Authentication を使用
// このバージョンはデモ用の簡易実装です

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // LocalStorageから認証情報を読み込み
  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      try {
        setCurrentUser(JSON.parse(savedUser));
      } catch (e) {
        console.error('ユーザー情報の読み込みに失敗しました');
      }
    }
    setLoading(false);
  }, []);

  // ログイン（デモ用）
  const login = (email, role = 'staff') => {
    const user = {
      email,
      role, // 'admin', 'editor', 'staff'
      displayName: email.split('@')[0],
      loginTime: new Date().toISOString()
    };
    setCurrentUser(user);
    localStorage.setItem('currentUser', JSON.stringify(user));
    return Promise.resolve(user);
  };

  // ログアウト
  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
    return Promise.resolve();
  };

  // 権限チェック
  const hasPermission = (requiredRole) => {
    if (!currentUser) return false;
    
    const roleHierarchy = {
      admin: 3,
      editor: 2,
      staff: 1
    };
    
    return roleHierarchy[currentUser.role] >= roleHierarchy[requiredRole];
  };

  // 自分のプロフィールかチェック
  const isOwnProfile = (email) => {
    return currentUser && currentUser.email === email;
  };

  const value = {
    currentUser,
    login,
    logout,
    hasPermission,
    isOwnProfile,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
