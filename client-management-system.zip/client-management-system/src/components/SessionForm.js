import React from 'react';

const SessionForm = ({ sessionForm, setSessionForm, onSubmit, onCancel }) => {
  return (
    <div className="bg-cyan-50 p-6 rounded-lg mb-6 border-2 border-cyan-300 shadow-md">
      <h2 className="text-xl font-bold mb-4 text-cyan-800">新規セッション記録</h2>
      <form onSubmit={onSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">
              セッション日 <span className="text-xs text-gray-500">年 / 月 / 日</span>
            </label>
            <input 
              type="date" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={sessionForm.date}
              onChange={(e) => setSessionForm({...sessionForm, date: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">
              担当者 <span className="text-xs text-cyan-600">{sessionForm.staff}</span>
            </label>
            <input 
              type="text" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={sessionForm.staff}
              onChange={(e) => setSessionForm({...sessionForm, staff: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">
              所要時間 <span className="text-xs text-cyan-600">{sessionForm.duration}</span>
            </label>
            <input 
              type="text" 
              placeholder="例: 60分" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={sessionForm.duration}
              onChange={(e) => setSessionForm({...sessionForm, duration: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">
              所管 <span className="text-xs text-cyan-600">{sessionForm.jurisdiction}</span>
            </label>
            <input 
              type="text" 
              placeholder="例: 東京オフィス" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={sessionForm.jurisdiction}
              onChange={(e) => setSessionForm({...sessionForm, jurisdiction: e.target.value})}
            />
          </div>
          
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-1 text-gray-700">
              お題 <span className="text-xs text-cyan-600">{sessionForm.topic}</span>
            </label>
            <input 
              type="text" 
              placeholder="例: 仕事とプライベートのバランス" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={sessionForm.topic}
              onChange={(e) => setSessionForm({...sessionForm, topic: e.target.value})}
            />
          </div>
          
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-1 text-gray-700">内容</label>
            <textarea 
              rows="3" 
              placeholder="セッションの内容を記入してください" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={sessionForm.content}
              onChange={(e) => setSessionForm({...sessionForm, content: e.target.value})}
            />
          </div>
          
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-1 text-gray-700">根本感情</label>
            <input 
              type="text" 
              placeholder="例: 不安、焦燥感" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={sessionForm.rootEmotion}
              onChange={(e) => setSessionForm({...sessionForm, rootEmotion: e.target.value})}
            />
          </div>
          
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-1 text-gray-700">特記事項</label>
            <textarea 
              rows="3" 
              placeholder="特記事項があれば記入してください" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={sessionForm.notes}
              onChange={(e) => setSessionForm({...sessionForm, notes: e.target.value})}
            />
          </div>
          
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-1 text-gray-700">次回への申し送り事項</label>
            <textarea 
              rows="2" 
              placeholder="次回のセッションで確認すべきことを記入してください" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={sessionForm.nextSession}
              onChange={(e) => setSessionForm({...sessionForm, nextSession: e.target.value})}
            />
          </div>
          
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-1 text-gray-700">備考</label>
            <textarea 
              rows="2" 
              placeholder="その他の備考があれば記入してください" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={sessionForm.remarks}
              onChange={(e) => setSessionForm({...sessionForm, remarks: e.target.value})}
            />
          </div>
        </div>
        
        <div className="flex gap-3 mt-4">
          <button 
            type="submit"
            className="bg-cyan-500 text-white px-6 py-2 rounded-lg hover:bg-cyan-600 transition shadow-md font-semibold"
          >
            記録を保存
          </button>
          <button 
            type="button"
            onClick={onCancel}
            className="bg-gray-300 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-400 transition"
          >
            キャンセル
          </button>
        </div>
      </form>
    </div>
  );
};

export default SessionForm;
