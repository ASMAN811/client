import React from 'react';
import { Eye } from 'lucide-react';

const ClientTable = ({ clients, onClientSelect }) => {
  return (
    <div className="overflow-x-auto shadow-md rounded-lg -mx-4 md:mx-0">
      <table className="w-full min-w-[640px]">
        <thead className="bg-cyan-400 text-white">
          <tr>
            <th className="px-2 md:px-4 py-2 md:py-3 text-left text-xs md:text-sm font-semibold">ID</th>
            <th className="px-2 md:px-4 py-2 md:py-3 text-left text-xs md:text-sm font-semibold">氏名</th>
            <th className="px-2 md:px-4 py-2 md:py-3 text-left text-xs md:text-sm font-semibold hidden md:table-cell">カナ</th>
            <th className="px-2 md:px-4 py-2 md:py-3 text-left text-xs md:text-sm font-semibold hidden sm:table-cell">年齢</th>
            <th className="px-2 md:px-4 py-2 md:py-3 text-left text-xs md:text-sm font-semibold hidden lg:table-cell">性別</th>
            <th className="px-2 md:px-4 py-2 md:py-3 text-left text-xs md:text-sm font-semibold hidden lg:table-cell">担当者</th>
            <th className="px-2 md:px-4 py-2 md:py-3 text-left text-xs md:text-sm font-semibold">記録</th>
            <th className="px-2 md:px-4 py-2 md:py-3 text-center text-xs md:text-sm font-semibold">操作</th>
          </tr>
        </thead>
        <tbody>
          {clients.map((client, index) => (
            <tr key={client.id} className={index % 2 === 0 ? 'bg-white' : 'bg-cyan-50'}>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm text-gray-700">{client.clientId}</td>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm font-medium">
                <button 
                  onClick={() => onClientSelect(client)}
                  className="text-cyan-600 hover:text-cyan-800 hover:underline truncate max-w-[120px] md:max-w-none block font-semibold"
                >
                  {client.name}
                </button>
              </td>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm text-gray-600 hidden md:table-cell">{client.kana}</td>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm text-gray-700 hidden sm:table-cell">{client.age}歳</td>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm text-gray-700 hidden lg:table-cell">{client.gender}</td>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm text-cyan-700 font-medium hidden lg:table-cell">{client.assignedStaff}</td>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm">
                <span className="bg-cyan-100 text-cyan-700 px-2 py-1 rounded-full text-xs font-medium">
                  {client.sessions.length}
                </span>
              </td>
              <td className="px-2 md:px-4 py-2 md:py-3 text-xs md:text-sm">
                <div className="flex justify-center">
                  <button 
                    onClick={() => onClientSelect(client)}
                    className="text-cyan-600 hover:text-cyan-800" 
                    title="詳細"
                  >
                    <Eye size={16} className="md:w-[18px] md:h-[18px]" />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {clients.length === 0 && (
        <div className="text-center py-8 text-gray-500 bg-white">
          該当するクライアント情報がありません
        </div>
      )}
    </div>
  );
};

export default ClientTable;
