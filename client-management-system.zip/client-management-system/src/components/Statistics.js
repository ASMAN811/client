import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const Statistics = ({ clients }) => {
  const [showDetailStats, setShowDetailStats] = useState(false);
  const [showMonthlyRevenue, setShowMonthlyRevenue] = useState(false);
  const [showStaffRevenue, setShowStaffRevenue] = useState(false);

  const totalSessions = clients.reduce((sum, c) => sum + c.sessions.length, 0);
  const maleCount = clients.filter(c => c.gender === '男性').length;
  const femaleCount = clients.filter(c => c.gender === '女性').length;

  // 担当者別クライアント数
  const getStaffClientCount = () => {
    const staffCount = {};
    clients.forEach(c => {
      const staff = c.assignedStaff || '未設定';
      staffCount[staff] = (staffCount[staff] || 0) + 1;
    });
    return Object.entries(staffCount).sort((a, b) => b[1] - a[1]);
  };

  // 性別分布
  const getGenderDistribution = () => {
    const genderCount = {};
    clients.forEach(c => {
      const gender = c.gender || '未設定';
      genderCount[gender] = (genderCount[gender] || 0) + 1;
    });
    return Object.entries(genderCount).sort((a, b) => b[1] - a[1]);
  };

  // 担当者別セッション数
  const getStaffSessionCount = () => {
    const staffSessionCount = {};
    clients.forEach(c => {
      c.sessions.forEach(s => {
        const staff = s.staff || '未設定';
        staffSessionCount[staff] = (staffSessionCount[staff] || 0) + 1;
      });
    });
    return Object.entries(staffSessionCount).sort((a, b) => b[1] - a[1]);
  };

  // 根本感情TOP10
  const getTopEmotions = () => {
    const emotionCount = {};
    clients.forEach(c => {
      c.sessions.forEach(s => {
        if (s.rootEmotion) {
          const emotions = s.rootEmotion.split(/[、,，]/).map(e => e.trim()).filter(e => e);
          emotions.forEach(emotion => {
            emotionCount[emotion] = (emotionCount[emotion] || 0) + 1;
          });
        }
      });
    });
    return Object.entries(emotionCount).sort((a, b) => b[1] - a[1]).slice(0, 10);
  };

  // 月別売上統計
  const getMonthlyRevenue = () => {
    const monthlyRevenue = {};
    clients.forEach(c => {
      const price = Number(c.sessionPrice) || 0;
      c.sessions.forEach(s => {
        const date = new Date(s.date);
        const yearMonth = `${date.getFullYear()}年${String(date.getMonth() + 1).padStart(2, '0')}月`;
        if (!monthlyRevenue[yearMonth]) {
          monthlyRevenue[yearMonth] = { count: 0, revenue: 0 };
        }
        monthlyRevenue[yearMonth].count += 1;
        monthlyRevenue[yearMonth].revenue += price;
      });
    });
    
    return Object.entries(monthlyRevenue).sort((a, b) => {
      const [yearA, monthA] = a[0].match(/\d+/g).map(Number);
      const [yearB, monthB] = b[0].match(/\d+/g).map(Number);
      return yearB * 12 + monthB - (yearA * 12 + monthA);
    });
  };

  // 担当者別売上統計
  const getStaffRevenue = () => {
    const staffRevenue = {};
    clients.forEach(c => {
      const price = Number(c.sessionPrice) || 0;
      c.sessions.forEach(s => {
        const staff = s.staff || '未設定';
        if (!staffRevenue[staff]) {
          staffRevenue[staff] = { count: 0, revenue: 0 };
        }
        staffRevenue[staff].count += 1;
        staffRevenue[staff].revenue += price;
      });
    });
    return Object.entries(staffRevenue).sort((a, b) => b[1].revenue - a[1].revenue);
  };

  return (
    <div className="mt-4 md:mt-6 space-y-4 md:space-y-6">
      {/* 基本統計 */}
      <div className="bg-gradient-to-r from-cyan-300 to-cyan-400 text-white p-4 md:p-6 rounded-lg shadow-lg">
        <h3 className="font-semibold mb-3 md:mb-4 text-base md:text-lg">クライアント統計</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4">
          <div className="bg-white bg-opacity-70 p-3 md:p-4 rounded-lg backdrop-blur-sm border border-cyan-500 border-opacity-30">
            <p className="text-xs md:text-sm text-cyan-800">総数</p>
            <p className="text-xl md:text-3xl font-bold mt-1 md:mt-2 text-cyan-700">{clients.length}</p>
          </div>
          <div className="bg-white bg-opacity-70 p-3 md:p-4 rounded-lg backdrop-blur-sm border border-cyan-500 border-opacity-30">
            <p className="text-xs md:text-sm text-cyan-800">男性</p>
            <p className="text-xl md:text-3xl font-bold mt-1 md:mt-2 text-cyan-700">{maleCount}</p>
          </div>
          <div className="bg-white bg-opacity-70 p-3 md:p-4 rounded-lg backdrop-blur-sm border border-cyan-500 border-opacity-30">
            <p className="text-xs md:text-sm text-cyan-800">女性</p>
            <p className="text-xl md:text-3xl font-bold mt-1 md:mt-2 text-cyan-700">{femaleCount}</p>
          </div>
          <div className="bg-white bg-opacity-70 p-3 md:p-4 rounded-lg backdrop-blur-sm border border-cyan-500 border-opacity-30">
            <p className="text-xs md:text-sm text-cyan-800">総セッション数</p>
            <p className="text-xl md:text-3xl font-bold mt-1 md:mt-2 text-cyan-700">{totalSessions}</p>
          </div>
        </div>
        <button 
          onClick={() => setShowDetailStats(!showDetailStats)}
          className="mt-3 md:mt-4 w-full bg-white bg-opacity-60 hover:bg-opacity-80 text-cyan-800 px-4 py-2 rounded-lg transition flex items-center justify-center gap-2 border border-cyan-500 border-opacity-30 font-semibold text-sm md:text-base"
        >
          {showDetailStats ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
          {showDetailStats ? '詳細統計を非表示' : '詳細統計を表示'}
        </button>
      </div>

      {showDetailStats && (
        <>
          {/* 詳細統計グリッド */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* 担当者別クライアント数 */}
            <div className="bg-white border-2 border-cyan-200 rounded-lg p-5 shadow-md">
              <h3 className="font-semibold mb-4 text-cyan-800 text-lg">担当者別クライアント数</h3>
              <div className="space-y-2">
                {getStaffClientCount().map(([staff, count]) => (
                  <div key={staff} className="flex justify-between items-center py-3 border-b border-cyan-100">
                    <span className="text-sm font-medium text-gray-700">{staff}</span>
                    <span className="text-lg font-bold text-cyan-600">{count}名</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 性別分布 */}
            <div className="bg-white border-2 border-cyan-200 rounded-lg p-5 shadow-md">
              <h3 className="font-semibold mb-4 text-cyan-800 text-lg">性別分布</h3>
              <div className="space-y-2">
                {getGenderDistribution().map(([gender, count]) => (
                  <div key={gender} className="flex justify-between items-center py-3 border-b border-cyan-100">
                    <span className="text-sm font-medium text-gray-700">{gender}</span>
                    <span className="text-lg font-bold text-pink-600">{count}名</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 担当者別セッション数 */}
            <div className="bg-white border-2 border-cyan-200 rounded-lg p-5 shadow-md">
              <h3 className="font-semibold mb-4 text-cyan-800 text-lg">担当者別セッション数</h3>
              <div className="space-y-2">
                {getStaffSessionCount().map(([staff, count]) => (
                  <div key={staff} className="flex justify-between items-center py-3 border-b border-cyan-100">
                    <span className="text-sm font-medium text-gray-700">{staff}</span>
                    <span className="text-lg font-bold text-green-700">{count}件</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 根本感情TOP10 */}
            <div className="bg-white border-2 border-cyan-200 rounded-lg p-5 shadow-md">
              <h3 className="font-semibold mb-4 text-cyan-800 text-lg">根本感情TOP10</h3>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {getTopEmotions().map(([emotion, count]) => (
                  <div key={emotion} className="flex justify-between items-center py-3 border-b border-cyan-100">
                    <span className="text-sm font-medium text-gray-700">{emotion}</span>
                    <span className="text-lg font-bold text-purple-700">{count}件</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 月別売上統計 */}
          <div className="bg-white border-2 border-cyan-200 rounded-lg p-5 shadow-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-cyan-800 text-lg">月別セッション売上統計</h3>
              <button 
                onClick={() => setShowMonthlyRevenue(!showMonthlyRevenue)}
                className="text-cyan-700 hover:text-cyan-900 transition"
              >
                {showMonthlyRevenue ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
              </button>
            </div>
            <div className="space-y-3">
              {getMonthlyRevenue().map(([month, data]) => (
                <div key={month} className="flex justify-between items-center py-3 px-4 bg-cyan-50 rounded-lg border border-cyan-200">
                  <div>
                    <span className="text-sm font-semibold text-gray-800">{month}</span>
                    <span className="text-xs text-gray-600 ml-3">セッション数: {data.count}件</span>
                  </div>
                  {showMonthlyRevenue && (
                    <span className="text-xl font-bold text-green-700">¥{data.revenue.toLocaleString()}</span>
                  )}
                </div>
              ))}
              {totalSessions === 0 && (
                <p className="text-center text-gray-500 py-4">セッションデータがありません</p>
              )}
            </div>
          </div>

          {/* 担当者別売上統計 */}
          <div className="bg-white border-2 border-cyan-200 rounded-lg p-5 shadow-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-cyan-800 text-lg">担当者別売上統計</h3>
              <button 
                onClick={() => setShowStaffRevenue(!showStaffRevenue)}
                className="text-cyan-700 hover:text-cyan-900 transition"
              >
                {showStaffRevenue ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
              </button>
            </div>
            <div className="space-y-3">
              {getStaffRevenue().map(([staff, data]) => (
                <div key={staff} className="flex justify-between items-center py-3 px-4 bg-cyan-50 rounded-lg border border-cyan-200">
                  <div>
                    <span className="text-sm font-semibold text-gray-800">{staff}</span>
                    <span className="text-xs text-gray-600 ml-3">セッション数: {data.count}件</span>
                  </div>
                  {showStaffRevenue && (
                    <span className="text-xl font-bold text-green-700">¥{data.revenue.toLocaleString()}</span>
                  )}
                </div>
              ))}
              {totalSessions === 0 && (
                <p className="text-center text-gray-500 py-4">セッションデータがありません</p>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Statistics;
