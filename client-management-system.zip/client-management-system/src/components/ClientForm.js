import React from 'react';

const ClientForm = ({ clientForm, setClientForm, onSubmit, onCancel, editingClientId }) => {
  return (
    <div className="bg-cyan-50 p-6 rounded-lg mb-6 border border-cyan-200">
      <h2 className="text-xl font-bold mb-4 text-cyan-800">
        {editingClientId ? 'クライアント情報編集' : '新規クライアント登録'}
      </h2>
      <form onSubmit={onSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">クライアントID</label>
            <input 
              type="text" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={clientForm.clientId}
              onChange={(e) => setClientForm({...clientForm, clientId: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">氏名</label>
            <input 
              type="text" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={clientForm.name}
              onChange={(e) => setClientForm({...clientForm, name: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">カナ</label>
            <input 
              type="text" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={clientForm.kana}
              onChange={(e) => setClientForm({...clientForm, kana: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">生年月日</label>
            <input 
              type="date" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={clientForm.birthDate}
              onChange={(e) => setClientForm({...clientForm, birthDate: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">性別</label>
            <select 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={clientForm.gender}
              onChange={(e) => setClientForm({...clientForm, gender: e.target.value})}
            >
              <option>男性</option>
              <option>女性</option>
              <option>その他</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">血液型</label>
            <select 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={clientForm.bloodType}
              onChange={(e) => setClientForm({...clientForm, bloodType: e.target.value})}
            >
              <option value="">選択</option>
              <option>A型</option>
              <option>B型</option>
              <option>O型</option>
              <option>AB型</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">電話番号</label>
            <input 
              type="tel" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={clientForm.phone}
              onChange={(e) => setClientForm({...clientForm, phone: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">地域</label>
            <input 
              type="text" 
              placeholder="例: 東京都渋谷区" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={clientForm.area}
              onChange={(e) => setClientForm({...clientForm, area: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">紹介者</label>
            <input 
              type="text" 
              placeholder="例: 田中様からのご紹介" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={clientForm.referrer}
              onChange={(e) => setClientForm({...clientForm, referrer: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">担当者</label>
            <input 
              type="text" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={clientForm.assignedStaff}
              onChange={(e) => setClientForm({...clientForm, assignedStaff: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">セッション金額(円)</label>
            <input 
              type="number" 
              placeholder="例: 10000" 
              className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
              value={clientForm.sessionPrice}
              onChange={(e) => setClientForm({...clientForm, sessionPrice: e.target.value})}
            />
          </div>
        </div>
        
        <div className="flex gap-3 mt-6">
          <button 
            type="submit"
            className="bg-cyan-400 text-white px-6 py-2 rounded-lg hover:bg-cyan-500 transition shadow-md font-semibold"
          >
            {editingClientId ? '更新' : '登録'}
          </button>
          <button 
            type="button"
            onClick={onCancel}
            className="bg-gray-300 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-400 transition"
          >
            キャンセル
          </button>
        </div>
      </form>
    </div>
  );
};

export default ClientForm;
