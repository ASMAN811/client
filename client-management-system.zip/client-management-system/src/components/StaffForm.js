import React from 'react';
import { useAuth } from '../contexts/AuthContext';

const StaffForm = ({ staffForm, setStaffForm, onSubmit, onCancel, editingStaffId }) => {
  const { currentUser, hasPermission, isOwnProfile } = useAuth();
  
  // 編集権限チェック
  const canEdit = hasPermission('editor') || (editingStaffId && isOwnProfile(staffForm.email));

  if (!canEdit && editingStaffId) {
    return (
      <div className="bg-red-50 p-6 rounded-lg mb-6 border border-red-200">
        <p className="text-red-700">このプロフィールを編集する権限がありません。</p>
      </div>
    );
  }

  return (
    <div className="bg-cyan-50 p-6 rounded-lg mb-6 border border-cyan-200">
      <h2 className="text-xl font-bold mb-4 text-cyan-800">
        {editingStaffId ? '担当者情報編集' : '新規担当者登録'}
      </h2>
      <form onSubmit={onSubmit}>
        <div className="space-y-6">
          {/* 基本情報 */}
          <div className="bg-white p-4 rounded-lg border border-cyan-200">
            <h3 className="font-semibold text-cyan-700 mb-3 text-lg">基本情報</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">
                  メールアドレス <span className="text-red-500">*</span>
                </label>
                <input 
                  type="email" 
                  required
                  disabled={editingStaffId}
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300 disabled:bg-gray-100" 
                  value={staffForm.email}
                  onChange={(e) => setStaffForm({...staffForm, email: e.target.value})}
                />
                {editingStaffId && (
                  <p className="text-xs text-gray-500 mt-1">メールアドレスは変更できません</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">
                  氏名 <span className="text-red-500">*</span>
                </label>
                <input 
                  type="text" 
                  required
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.name}
                  onChange={(e) => setStaffForm({...staffForm, name: e.target.value})}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">
                  ふりがな <span className="text-red-500">*</span>
                </label>
                <input 
                  type="text" 
                  required
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.kana}
                  onChange={(e) => setStaffForm({...staffForm, kana: e.target.value})}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">生年月日</label>
                <input 
                  type="date" 
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.birthDate}
                  onChange={(e) => setStaffForm({...staffForm, birthDate: e.target.value})}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">居住地</label>
                <input 
                  type="text" 
                  placeholder="例: 東京都渋谷区"
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.location}
                  onChange={(e) => setStaffForm({...staffForm, location: e.target.value})}
                />
              </div>
            </div>
          </div>

          {/* 連絡先情報 */}
          <div className="bg-white p-4 rounded-lg border border-cyan-200">
            <h3 className="font-semibold text-cyan-700 mb-3 text-lg">連絡先情報</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">電話番号</label>
                <input 
                  type="tel" 
                  placeholder="例: 090-1234-5678"
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.phone}
                  onChange={(e) => setStaffForm({...staffForm, phone: e.target.value})}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">LINE ID</label>
                <input 
                  type="text" 
                  placeholder="例: your_line_id"
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.lineId}
                  onChange={(e) => setStaffForm({...staffForm, lineId: e.target.value})}
                />
              </div>
            </div>
          </div>

          {/* 家族構成 */}
          <div className="bg-white p-4 rounded-lg border border-cyan-200">
            <h3 className="font-semibold text-cyan-700 mb-3 text-lg">家族構成</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">姉妹兄弟構成（自身）</label>
                <input 
                  type="text" 
                  placeholder="例: 3人兄弟の長男（弟2人）"
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.siblingsStructure}
                  onChange={(e) => setStaffForm({...staffForm, siblingsStructure: e.target.value})}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">家族構成</label>
                <input 
                  type="text" 
                  placeholder="例: 既婚、配偶者と子供2人"
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.familyStructure}
                  onChange={(e) => setStaffForm({...staffForm, familyStructure: e.target.value})}
                />
              </div>
            </div>
          </div>

          {/* 専門情報 */}
          <div className="bg-white p-4 rounded-lg border border-cyan-200">
            <h3 className="font-semibold text-cyan-700 mb-3 text-lg">専門情報</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">DNA歴</label>
                <textarea 
                  rows="3" 
                  placeholder="例: DNA Basic修了 (2020年)&#10;DNA Advance修了 (2021年)"
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.dnaHistory}
                  onChange={(e) => setStaffForm({...staffForm, dnaHistory: e.target.value})}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">職業経歴（詳細に）</label>
                <textarea 
                  rows="8" 
                  placeholder="職業経歴を詳しく記入してください&#10;&#10;例:&#10;■ 2010年〜2015年: 株式会社○○&#10;・人事部門にて採用・教育研修を担当&#10;..."
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.careerHistory}
                  onChange={(e) => setStaffForm({...staffForm, careerHistory: e.target.value})}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">公的な資格</label>
                <textarea 
                  rows="3" 
                  placeholder="例: 公認心理師（登録番号: 12345）&#10;キャリアコンサルタント（国家資格）"
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.certifications}
                  onChange={(e) => setStaffForm({...staffForm, certifications: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">稼働可能時間</label>
                <textarea 
                  rows="3" 
                  placeholder="例: 平日: 10:00-18:00&#10;土曜: 10:00-15:00&#10;日曜・祝日: 休み"
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.availableHours}
                  onChange={(e) => setStaffForm({...staffForm, availableHours: e.target.value})}
                />
              </div>
            </div>
          </div>

          {/* 使命・その他 */}
          <div className="bg-white p-4 rounded-lg border border-cyan-200">
            <h3 className="font-semibold text-cyan-700 mb-3 text-lg">使命・その他</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">自身の使命</label>
                <textarea 
                  rows="4" 
                  placeholder="あなたの使命や想いを記入してください"
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.mission}
                  onChange={(e) => setStaffForm({...staffForm, mission: e.target.value})}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">その他</label>
                <textarea 
                  rows="4" 
                  placeholder="その他の情報（得意分野、趣味など）"
                  className="w-full px-3 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300" 
                  value={staffForm.otherInfo}
                  onChange={(e) => setStaffForm({...staffForm, otherInfo: e.target.value})}
                />
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex gap-3 mt-6">
          <button 
            type="submit"
            className="bg-cyan-400 text-white px-6 py-2 rounded-lg hover:bg-cyan-500 transition shadow-md font-semibold"
          >
            {editingStaffId ? '更新' : '登録'}
          </button>
          <button 
            type="button"
            onClick={onCancel}
            className="bg-gray-300 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-400 transition"
          >
            キャンセル
          </button>
        </div>

        {editingStaffId && (
          <div className="mt-4 text-xs text-gray-600 bg-gray-50 p-3 rounded">
            <p>編集者: {currentUser?.email}</p>
          </div>
        )}
      </form>
    </div>
  );
};

export default StaffForm;
