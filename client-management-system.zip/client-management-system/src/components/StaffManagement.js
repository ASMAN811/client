import React, { useState, useEffect } from 'react';
import { Plus, Search, ArrowLeft } from 'lucide-react';
import { calculateAge } from '../utils/dateUtils';
import { loadStaffFromStorage, saveStaffToStorage, updateStaffWithHistory, createNewStaff } from '../utils/staffStorageUtils';
import { useAuth } from '../contexts/AuthContext';
import StaffList from './StaffList';
import StaffForm from './StaffFormNew';
import StaffDetail from './StaffDetailNew';

const StaffManagement = ({ onBack }) => {
  const { currentUser, hasPermission, isOwnProfile } = useAuth();
  const [staff, setStaff] = useState(() => loadStaffFromStorage());
  const [selectedStaff, setSelectedStaff] = useState(null);
  const [viewMode, setViewMode] = useState('list'); // 'list' or 'detail'
  const [isStaffFormOpen, setIsStaffFormOpen] = useState(false);
  const [editingStaffId, setEditingStaffId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const [staffForm, setStaffForm] = useState({
    email: '',
    name: '',
    kana: '',
    birthDate: '',
    location: '',
    dnaHistory: '',
    careerHistory: '',
    certifications: '',
    siblingsStructure: '',
    familyStructure: '',
    availableHours: '',
    phone: '',
    lineId: '',
    mission: '',
    otherInfo: ''
  });

  // データが変更されたらLocalStorageに保存
  useEffect(() => {
    saveStaffToStorage(staff);
  }, [staff]);

  const resetStaffForm = () => {
    setStaffForm({
      email: '',
      name: '',
      kana: '',
      birthDate: '',
      location: '',
      dnaHistory: '',
      careerHistory: '',
      certifications: '',
      siblingsStructure: '',
      familyStructure: '',
      availableHours: '',
      phone: '',
      lineId: '',
      mission: '',
      otherInfo: ''
    });
    setIsStaffFormOpen(false);
    setEditingStaffId(null);
  };

  const handleStaffSubmit = (e) => {
    e.preventDefault();
    
    // 権限チェック
    if (editingStaffId && !hasPermission('editor') && !isOwnProfile(staffForm.email)) {
      alert('このプロフィールを編集する権限がありません');
      return;
    }

    const age = staffForm.birthDate ? calculateAge(staffForm.birthDate) : null;

    if (editingStaffId) {
      // 編集
      const updatedData = { ...staffForm, id: editingStaffId, age };
      const updatedStaff = updateStaffWithHistory(staff, updatedData, currentUser.email);
      setStaff(updatedStaff);
      
      // 詳細ビューを更新
      if (selectedStaff && selectedStaff.id === editingStaffId) {
        setSelectedStaff(updatedStaff.find(s => s.id === editingStaffId));
      }
    } else {
      // 新規登録（管理者・編集者のみ）
      if (!hasPermission('editor')) {
        alert('新規登録する権限がありません');
        return;
      }
      const newStaffData = createNewStaff({ ...staffForm, age }, currentUser.email);
      setStaff([...staff, newStaffData]);
    }
    resetStaffForm();
  };

  const handleEditStaff = (person) => {
    setStaffForm(person);
    setEditingStaffId(person.id);
    setIsStaffFormOpen(true);
    setViewMode('list');
  };

  const handleDeleteStaff = (id) => {
    if (!hasPermission('admin')) {
      alert('削除する権限がありません（管理者のみ）');
      return;
    }
    setStaff(staff.filter(s => s.id !== id));
    if (selectedStaff && selectedStaff.id === id) {
      setSelectedStaff(null);
      setViewMode('list');
    }
  };

  const handleStaffSelect = (person) => {
    setSelectedStaff(person);
    setViewMode('detail');
  };

  const filteredStaff = staff.filter(s =>
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.kana.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // 詳細ビュー
  if (viewMode === 'detail' && selectedStaff) {
    return (
      <StaffDetail
        staff={selectedStaff}
        onBack={() => setViewMode('list')}
        onEdit={handleEditStaff}
        onDelete={handleDeleteStaff}
      />
    );
  }

  // リストビュー
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50 p-3 md:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-4 md:p-6">
          {/* ヘッダー */}
          <div className="border-b-4 border-cyan-400 pb-3 md:pb-4 mb-4 md:mb-6">
            <button 
              onClick={onBack}
              className="mb-3 text-cyan-700 hover:text-cyan-900 font-medium flex items-center gap-2"
            >
              <ArrowLeft size={20} />
              メインメニューに戻る
            </button>
            <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-3">
              <div>
                <h1 className="text-xl md:text-3xl font-bold text-cyan-800">担当者管理</h1>
                <p className="text-xs md:text-sm text-cyan-600 mt-1">Staff Management</p>
              </div>
              <div className="text-sm text-gray-600">
                登録担当者数: <span className="font-bold text-cyan-700">{staff.length}名</span>
              </div>
            </div>
          </div>

          {/* 検索バーと新規登録ボタン */}
          <div className="flex gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="担当者名、ふりがなで検索..."
                className="w-full pl-10 pr-4 py-2 border border-cyan-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-300"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <button
              onClick={() => {
                setIsStaffFormOpen(true);
                setEditingStaffId(null);
                resetStaffForm();
              }}
              className="flex items-center gap-2 bg-cyan-400 text-white px-6 py-2 rounded-lg hover:bg-cyan-500 transition shadow-md font-semibold"
            >
              <Plus size={20} />
              新規担当者登録
            </button>
          </div>

          {/* 担当者フォーム */}
          {isStaffFormOpen && (
            <StaffForm
              staffForm={staffForm}
              setStaffForm={setStaffForm}
              onSubmit={handleStaffSubmit}
              onCancel={resetStaffForm}
              editingStaffId={editingStaffId}
            />
          )}

          {/* 担当者一覧テーブル */}
          <StaffList
            staff={filteredStaff}
            onStaffSelect={handleStaffSelect}
            onEdit={handleEditStaff}
            onDelete={handleDeleteStaff}
          />
        </div>
      </div>
    </div>
  );
};

export default StaffManagement;
