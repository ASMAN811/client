import React from 'react';
import { Trash2 } from 'lucide-react';

const SessionList = ({ sessions, onDelete }) => {
  if (sessions.length === 0) {
    return (
      <p className="text-center text-gray-500 py-8 bg-cyan-50 rounded-lg">
        セッション記録がありません
      </p>
    );
  }

  return (
    <div className="space-y-4">
      {sessions.slice().reverse().map((session) => (
        <div key={session.id} className="border border-cyan-200 rounded-lg p-4 hover:shadow-md transition bg-white">
          <div className="flex justify-between items-start mb-3">
            <div>
              <p className="text-lg font-bold text-cyan-800">{session.date}</p>
              <p className="text-sm text-gray-600">
                担当者: {session.staff} | 所要時間: {session.duration} | 所管: {session.jurisdiction}
              </p>
            </div>
            <button 
              onClick={() => {
                if (window.confirm('このセッション記録を削除しますか？')) {
                  onDelete(session.id);
                }
              }}
              className="text-red-600 hover:text-red-800"
            >
              <Trash2 size={18} />
            </button>
          </div>
          
          <div className="space-y-2">
            <div>
              <span className="text-sm font-semibold text-gray-700">お題: </span>
              <span className="text-sm text-cyan-700 font-medium">{session.topic}</span>
            </div>
            
            <div>
              <span className="text-sm font-semibold text-gray-700">内容: </span>
              <span className="text-sm text-gray-700">{session.content}</span>
            </div>
            
            <div className="bg-purple-50 p-2 rounded">
              <span className="text-sm font-semibold text-gray-700">根本感情: </span>
              <span className="text-sm text-purple-700">{session.rootEmotion}</span>
            </div>
            
            {session.notes && (
              <div>
                <span className="text-sm font-semibold text-gray-700">特記事項: </span>
                <span className="text-sm text-gray-700">{session.notes}</span>
              </div>
            )}
            
            {session.nextSession && (
              <div className="bg-cyan-50 p-2 rounded">
                <span className="text-sm font-semibold text-gray-700">次回への申し送り事項: </span>
                <span className="text-sm text-cyan-700">{session.nextSession}</span>
              </div>
            )}
            
            {session.remarks && (
              <div>
                <span className="text-sm font-semibold text-gray-700">備考: </span>
                <span className="text-sm text-gray-600">{session.remarks}</span>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default SessionList;
