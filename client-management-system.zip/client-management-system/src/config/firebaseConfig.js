// Firebase設定
// 注意: このファイルは実際の本番環境では .env ファイルで管理してください

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

export default firebaseConfig;

// セットアップ手順:
// 1. Firebase Console (https://console.firebase.google.com/) にアクセス
// 2. 新しいプロジェクトを作成
// 3. Authentication > Sign-in method で Google を有効化
// 4. プロジェクト設定からFirebase SDK の設定をコピー
// 5. 上記の YOUR_* 部分を実際の値に置き換え
